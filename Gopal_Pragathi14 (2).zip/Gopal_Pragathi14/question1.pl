/* Author: Pragathi Gopal */

/* Question 1 */

/* if y <= 0 then it will essentially return x */
/* size-n problem */ 
foo(X,Y,Z) :- Y =< 0, Z is X. 


/* if x <= 0 then return y*/
/*stopping condition*/
foo(X,Y,Z) :- X =< 0, Z is Y.

/* if x >= y then return x + foo(x-2,y) */
/* size-m problem*/
foo(X,Y,Z) :- X >= Y, foo(X-2, Y, Z2), Z is (X + Z2).

/* if x < y then return y + foo(x, y-3) */
/*size-n problems*/ 
/*solving size-m problem */
foo(X,Y,Z) :- X < Y, foo(X, Y-3, Z2), Z is (Y + Z2).
