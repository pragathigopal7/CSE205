
/*Question 2 */
pizza(P,S,B,O,M):-
	member(P,[0,1,2,3,4,5,6,7,8,9,10]),
	member(S,[0,1,2,3,4]),
	member(B,[0,1,2,3,4,5,6]),
	member(O,[0,1,2,3,4,5,6,7,8]),
	member(M,[0,1,2,3,4,5]),
	TP is 4*P,
	TS is 10*S,
	TB is 6*B,
	TO is 5*O,
	TM is 7*M,
	W is TP+TS+TB+TO+TM,
	W =:= 40.
	
	
% 2.2) P=1,B=1,M=0,O=6,S=0; P=1,B=1,M=0,O=4,S=1; P=1,B=1,M=0,O=2,S=2; and P=1,B=1,M=0,O=0,S=3.

/* 0 mushrooms, 6 onions, 0 sausages */ 
/* 0 mushrooms, 4 onions, 1 sausage */
/* 0 mushrooms, 2 onions, 2 sausages */
/* 0 mushrooms, 0 onions, 3 sausages */


% 2.3)  B=3,O=3,P=0,S=0,M=1; B=3,O=1,P=0,S=1,M=1;  B=4,O=1,P=1,S=0,M=1;  B=0,O=5,P=2,S=0,M=1;
% B=2,O=1,P=4,S=0,M=1; and B=0,O=1,P=7,S=0,M=1; B=1,O=3,P=3,S=1,M=1; B=1,O=1,P=3,S=1,M=1;
% B=0,O=3,P=2,S=1,M=1;  B=0,O=1,P=2,S=2,M=1; 

/* 3 bacon, 3 onions, 0 pepperoni, 0 sausage */
/* 3 bacon, 1 onion, 0 pepperoni, 1 sausage */
/* 4 bacon, 1 onions, 1 pepperoni, 0 sausage */
/* 0 bacon, 5 onion, 2 pepperonis, 0 sausages */
/* 0 bacon, 3 onions, 2 pepperoni, 1 sausage */
/* 0 bacon, 1 onion, 2 pepperoni, 2 sausage */
/* 1 bacon, 3 onions, 3 pepperoni, 0 sausage */
/* 1 bacon, 1 onion, 3 pepperoni, 1 sausage */
/* 2 bacon, 1 onions, 4 pepperoni, 0 sausage */
/* 0 bacon, 1 onion, 7 pepperoni, 0 sausage */

 

