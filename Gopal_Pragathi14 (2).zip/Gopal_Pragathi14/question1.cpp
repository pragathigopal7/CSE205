#include <stdlib.h>

#include <iostream>

int foo(int x, int y)
{
	if (y <= 0) 
		return x;  // size-n problem
	
	else if (x <= 0) //stopping condition
		return y; 
	
	else if (x >= y) 
		return x + foo(x - 2, y); //size-m problem 

	else if (x < y) 
		return y + foo(x, y - 3); 
	// size-n problem from a size-m problem
	return -1;
}
int main() 
{
	int value = foo(5, 6);

	printf("value %d", value);
}