#include "stdafx.h"
#include "Pet.h"

// Q1 : CLASS METHODS Part 1 : Constructor and Accessor Methods for Pet (5 points)

// Constructor
// Create a constructor for the class Pet which takes 2 string parameters (see helper function for use of constructor).
// Use the 2 string parameters to initialize the 2 private local variables name and breed.
// HINT: Don't forget to initialize your linked list of checkups to NULL.
Pet::Pet(string pet_name1, string breed_of_pet) // This statement creates the constructor 
{
	this->name = pet_name1; 
	this->breed = breed_of_pet;
	this->checkups = NULL;
}
// Code here

// Accessor Methods
// Create accessor methods for both private local strings name and breed (see print_all function for use of these methods).
string Pet::getNameofPet() //This statement creates an accessor method
{
	return name;
}
string Pet::getBreedPet() //accesses the breed of the pet
{
	return breed;
}



// Q2 : CLASS METHODS Part 2 : Class Methods for Pet (10 points)

// Create a method named "addCheckup" which has one string parameter and no return type (see helper function for use).
// This method is used to add a new date to the pet's linked list of checkups. The string parameter is the date of checkup.
// You should add the date to the tail of the linked list "checkups". Checkups will be added in chronological order.

void Pet::addCheckup(string date_of_checkup) // method for the checkup of the pet
{
	Checkup* one1 = new Checkup(date_of_checkup);
	one1->next = NULL; //moves to the next node in the list 
	if (checkups == NULL)
	{
		checkups = one1;
	}
	else
	{
		checkups->next = one1; // when the statement matches the node is moved to the next value in the list
	}
}

// Create a method named "lastCheckup" which has no parameters and returns a string (see print_all function for use).
// This method will be used to return a string for the date of the last checkup for this pet.
// If the pet has not yet had a checkups, return an empty string.

string Pet::lastCheckupofPet()
{
	if (checkups == NULL)
		return "";
	else
	{
		Checkup* current = checkups;
		Checkup* next = current->next;
		while (next != NULL)
		{
			current = next;
			next = current->next;
		}
		return current->getDateofPets();
	}
}


