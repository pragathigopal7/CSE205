/* This C program demonstrates the switch statement without using breaks. */
/* The program is tested on MS Visual C++ platform                        */
#include <stdio.h>
#pragma warning(disable : 4996) 

int main() {
	char chr;
	int i = 0; 
	for (printf(""); i < 5; i++)
	{
		ch = getchar(); //allows the input to be stored
			int f, a = 10, b = 20;
			switch (ch) 
			{
			case '+': f = a + b;  //this statement adds the respective values 
					printf("f = %g\n", f); break; // this statement prints the respective values   
			case '-': f = a - b; //this statement subtracts the respective values 
					printf("f = %g\n", f); break; 
			case '*': f = a * b; //this statement mutltiplies the values inputted values
					printf("f = %g\n", f); break;  
			case '/': f = a / b; //allows for the remainder of the value to be printed 
					printf("f = %g\n", f); break; 
			default: printf("invalid operator\n"); break;
			}
		return 0;
	}


	