/* This C program demonstrates the switch statement without using breaks. */
/* The program is tested on MS Visual C++ platform                        */
#include <stdio.h>
#pragma warning(disable : 4996) 

int main() {
	char ch;
	ch = '+';
	double f, a = 10, b = 20;
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f);
	case '-': f = a - b; printf("f = %g\n", f);
	case '*': f = a * b; printf("f = %g\n", f);
	case '/': f = a / b; printf("f = %g\n", f);
	default: printf("invalid operator\n");
	}
	ch = '-';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f);
	case '-': f = a - b; printf("f = %g\n", f);
	case '*': f = a * b; printf("f = %g\n", f);
	case '/': f = a / b; printf("f = %g\n", f);
	default: printf("invalid operator\n");
	}
	ch = '*';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f);
	case '-': f = a - b; printf("f = %g\n", f);
	case '*': f = a * b; printf("f = %g\n", f);
	case '/': f = a / b; printf("f = %g\n", f);
	default: printf("invalid operator\n");
	}
	ch = '/';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f);
	case '-': f = a - b; printf("f = %g\n", f);
	case '*': f = a * b; printf("f = %g\n", f);
	case '/': f = a / b; printf("f = %g\n", f);
	default: printf("invalid operator\n");
	}
	ch = '%';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f);
	case '-': f = a - b; printf("f = %g\n", f);
	case '*': f = a * b; printf("f = %g\n", f);
	case '/': f = a / b; printf("f = %g\n", f);
	default: printf("invalid operator\n");
	}
}
