/*Problem 3.1*/
status(jack, sophomore).
status(sam, freshman).

class(mat, calculus).
class(mat, algebra).

class(bio, taxonomy).
class(bio, evolution).

class(eng, reading).
class(eng, writing).

class(cse, algorithms).
class(cse, databases).

topic(jack, mat).
topic(jack, cse).

topic(sam, bio).
topic(sam, eng).

/*Problem 3.2*/
info(X, Y) :-

	status(X, A),
	write(A),
	nl,

	findsall(Y, topic(X, Y), Subjects),
	write(Subjects).

/*Problem 3.3*/
schedule(X, Y) :-

	findsall(Y, topic(X, Y), Subjects),
	member(Q, Subjects),
	
	findsall(Z, class(Q, Z), Classes),
	write(Classes).
